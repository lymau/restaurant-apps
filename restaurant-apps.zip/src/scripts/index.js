import 'regenerator-runtime'; /* for async await transpile */
import '../styles/main.css';
import '../styles/responsive.css';
import './script.js';

require('webpack-icons-installer/font-awesome'); //load only font-awesome icons

console.log('Hello Coders! :)');
